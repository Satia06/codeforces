#reverse phrase
#for example: Apples are red. output will be red are Apples

def ReverseString(string):
    lt1 = string.split(' ')#it splits the words or the string by a space 
    lt1.reverse() #this is inbuilt 
    lt1 = ' '.join(lt1) #join joins the string with the attribute before the '.'
    #for example if the #.join(list) is given then the elements of list will be joined as #inbetween them
    
    return lt1

String = input('Please enter a phrase: ')
Result= ReverseString(String)
print(Result)
