#remduploop
#remdupset

def RemDupLoop(list):
    res = []
    for num in list:
        if num not in res:
            res.append(num)
    return res

def RemDupSet(list):
    sorted_set = set(list)
    res =[]
    for ele in sorted_set:
        res.append(ele)
    return res
n = int(input("Enter the number of elements in the list: "))
lst = []
lst2 = []
print("Here 1 means you want to enter int type data and 0 means you want to enter string or character type data.")
take = int(input("Tell the type of input you want[0/1]: "))
if take == 0:
    for i in range(0,n):
        ele = input()
        lst2.append(ele.strip()) #.strip() removes the whitespace 
else:
    for i in range(0,n):
            ele = int(input())
            lst.append(ele)
#print("Here it means -1 you want to follow the method of sorting by loop while 99 means you want to sort by set.")
#choice = int(input("Enter the method you want do[-1,99]: "))

if take == 0:
    print("The list after duplicates removed by loop: ",RemDupLoop(lst2))
    print("The list after duplicates removed by set: ",RemDupSet(lst2))
else:
    print("The list after duplicates removed by loop: ",RemDupLoop(lst))
    print("The list after duplicates removed by set: ",RemDupSet(lst))
'''else:
    if take == 0:
        print(RemDupSet(lst2))
    else:
        print(RemDupSet(lst))'''
  
