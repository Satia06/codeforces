#Simple program for pascal triangle
#C(n,k) = C(n-1,k-1) + C(n-1,k).
#We know that the pascal triangle is
#the above two numbers will be added to get the value of number just below it 
#I am printing it in the form of
# 1
#121
#triangular pyramid types

def Pascal(n):
    for l in range(1,n+1):
        x = 1
        spaces = (n+1-l)* " " #space will be repeated (n+1-l) times
        print(spaces,end="\0")
        for i in range(1,l+1):
            print(x,end = " ");
            x = int(x*(l-i)/i)#printing first 1 then in the second line changing x value to
            #this will change the next value of x and then print and will go on.
        print(" ")

n = int(input())
Pascal(n)
