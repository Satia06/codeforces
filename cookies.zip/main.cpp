/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include,bits/stdc++.h>

using namespace std;

int main()
{
    unsigned int N,M, lastAns=0;
    cin>>N;
    unsigned int A[N];
    for(int i=0;i<N;i++)        cin>>A[i];
    cin>>M;
    unsinged int B[M];
    char S[M];
    for(int i=0;i<M;i++)      cin>>B[i];
    for(int i=0;i<M;i++)     cin>>S[i];
     
    unsigned int result[N];
    deque<unsigned int> cookiesOnTable;
    for(unsigned int i =0;i<N;i++){
        unsigned int real_A=(A[i]+lastAns)%1000000000;
        lastAns=0;
        A[i]=real_A;
        for(unsigned int k=0;k<=i;k++)cookiesOnTable.push_back(A[k]);
        for(unsigned int k=0;k<M;k++){
            cook.push_back(B[k]);
            if(S[k]=='S'){
                sort(cookiesOnTable.begin(),cookiesOnTable.end());
                cookiesOnTable.pop_back();
            }
            if(S[k]=='B'){
                sort(cookiesOnTable.begin(),cookiesOnTable.end());
                cookiesOnTable.pop_front();
            }
        }
        for(int i=0;i<cookiesOnTable.size();i++)     lastAns+=cookiesOnTable.at(i);
        result[i]=lastAns;
        cookiesOnTable.clear();
    }
    for(unsigned int i=0;i<N;i++)       print("%u",result[i]);
    return 0;
}
