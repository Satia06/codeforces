public class Team
{
	Member member;
	public team(Memeber member){
	    this.member = member;
	}
// here's our main method
    public static void main(string[] args){
        Member myMember  = new Member("Dastein", "Light", 10,1);
        Team myTeam = new Team(myMember);
        System.out.println(myTeam.member.getName());
        System.out.println(myTeam.member.getType());
        System.out.println(myTeam.member.getLevel());
        System.out.println(myTeam.member.getRank);
    }
    
}


class Member {
    private String name;
    private String type;
    private int level;
    private int rank;
    
    public Member(String name,String type, int level, int rank){
    this.name = name;
    this.type = type;
    this.level = level;
    this.rank = rank;
 }

    
/* let's define our getter function hers*/

public String getName(){//what is your name?
    return this.name;
  }


public String getType(){ // what is  your type?
    return this.type;
  }


public int getLevel(){ //what is your level?
    return this.level;
  }

public int getRank(){ //what is your rank?
    return this.rank;
  }

}